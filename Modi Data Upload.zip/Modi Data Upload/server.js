// Required imports
const express = require('express');
const axios = require('axios');
const querystring = require('querystring');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const { body, validationResult } = require('express-validator');

// Load environment variables
require('dotenv').config();

// Create Express app
const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());

// GitHub OAuth configuration
const clientId = process.env.CLIENT_ID;
const clientSecret = process.env.CLIENT_SECRET;

// GitHub repository details
const repoOwner = 'modi-data';
const repoName = 'modi-metadata';
const branch = 'main';

// Dictionary for contents to allow simultaneous use.
let contents = {};

// A semaphore to control access to the contents dictionary
const semaphore = require('semaphore')(1);

// Rate limiting configuration
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 5, // limit each IP to 5 requests per windowMs
  message: 'Too many requests from this IP, please try again later'
});

// Input validation for fileUpload endpoint
const fileUploadValidationRules = [
  body('filename').trim().notEmpty().isString(), // Validate filename
  body('content').trim().notEmpty().isString()   // Validate content
];

// OAuth login route with input validation and rate limiting
app.post('/MODI/fileUpload', limiter, fileUploadValidationRules, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const filename = req.body.filename;
  const content = req.body.content;

  // Add content to the dictionary
  semaphore.take(() => {
    contents[filename] = content;
    semaphore.leave();
  });

  // Schedule content deletion after one minute
  setTimeout(() => {
    semaphore.take(() => {
      delete contents[filename];
      semaphore.leave();
    });
  }, 60000); // 60000 milliseconds = 1 minute

  res.status(200).json({ message: 'File uploaded successfully!' });
});

// Ignore favicon requests
app.get('/MODI/favicon.ico', (req, res) => res.status(204).end());

// Route for handling OAuth callback from GitHub
app.get('/MODI/oauth/callback', async (req, res) => {
  const code = req.query.code; // Retrieve content from query parameters
  const filename = req.query.state;

  try {
    // Exchange code for access token
    const tokenResponse = await axios.post('https://github.com/login/oauth/access_token', querystring.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      code,
    }));

    const responseBody = tokenResponse.data;
    const accessToken = querystring.parse(responseBody).access_token;

    // Call uploadFile function to upload the file with the retrieved content
    await uploadFile(accessToken, filename);

    // Respond with success message
    res.send(`<h1>File uploaded successfully!</h1>
<h2>It should now be available on <a href="https://github.com/modi-data/modi-metadata/tree/main/yml">GitHub</a></h2>
<p>(It may take some time for the file to appear).</p>
<p><br>You can close this window.</p>`);
  } catch (error) {
    // Respond with HTML
    res.status(500).send(`<h1>File upload failed. Please try again later.</h1>
<h2>${error.message}</h2>
<p>Some common error codes: 
<br> 422: There already exists a file with this name. 
<br> 404: User has insufficient rights.</p>
<p><br>You can close this window.</p>`);
  }
  delete contents[filename];
});

// Function to upload the YAML file
async function uploadFile(accessToken, filenameRaw) {
  const filename = filenameRaw + '.yml';

  // Retrieve content from the dictionary
  let content;
  semaphore.take(() => {
    content = contents[filenameRaw];
    semaphore.leave();
  });

  if (!content) {
    throw new Error("Upload Timeout, try again.");
  } else {
    const encodedContent = Buffer.from(content || '').toString('base64'); // Use content passed from the client

    // Construct GitHub API request URL
    const url = `https://api.github.com/repos/${repoOwner}/${repoName}/contents/yml/${filename}`;

    try {
      await axios.put(url, {
        message: 'Upload YAML file',
        content: encodedContent,
        branch: branch,
      }, {
        headers: {
          Authorization: `token ${accessToken}`,
        },
      });
    } catch (error) {
      const errorMessage = "Github API upload error: " + error.message;
      throw new Error(errorMessage);;
    }
  }
}

// Start the server
const PORT = process.env.PORT || 3000; // Use environment variable for port or default to 3000
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));